#pragma once

#include <thread>
#include <chrono>
#include <iostream>
#include <filesystem>
#include <regex>
#include <utility>

#include <json/json.h>

#include <imgui.h>
#include <imgui_impl_win32.h>
#include <imgui_impl_dx11.h>
#include "imgui_freetype.h"